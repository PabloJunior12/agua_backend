from django.contrib import admin
# from .models import Reading

# # Register your models here.

# @admin.register(Reading)
# class ReadingAdmin(admin.ModelAdmin):
#     list_display = ('customer', 'reading_date', 'current_reading', 'consumption')
#     search_fields = ('customer__meter_code',)
#     list_filter = ('reading_date',)