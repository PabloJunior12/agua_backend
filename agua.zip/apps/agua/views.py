from django.shortcuts import render, get_object_or_404
from django_filters.rest_framework import DjangoFilterBackend
from django.template.loader import render_to_string, get_template
from django.http import HttpResponse
from django.conf import settings
from django.utils.timezone import now
from django.db import transaction
from django.db.models import Max, Sum, Count

from dateutil.relativedelta import relativedelta

from rest_framework.views import APIView
from rest_framework import filters, status, viewsets
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.pagination import PageNumberPagination
from rest_framework.exceptions import ValidationError

from datetime import datetime, date
from weasyprint import HTML, CSS
from collections import defaultdict
from babel.dates import format_date
from decimal import Decimal
from .models import Customer, WaterMeter, CashBox, Reading, Invoice, Category, Via, Calle, InvoiceDebt, InvoicePayment, Zona, Debt, ReadingGeneration, Company
from .serializers import (
    CustomerSerializer, WaterMeterSerializer, ViaSerializer, CalleSerializer, DebtSerializer, CashBoxSerializer, CustomerWithDebtsSerializer,
    ReadingSerializer,  InvoiceSerializer, CategorySerializer, ZonaSerializer, ReadingGenerationSerializer
)

from PyPDF2 import PdfMerger 
import calendar
import io
import pandas as pd
import os
import tempfile
import zipfile

from .utils import ReadingFilter, DebtFilter, to_none_if_empty, to_decimal_or_none, generar_periodos

class CustomPagination(PageNumberPagination):

    page_size = 5  # Número de registros por página
    page_size_query_param = 'page_size'  # Permite cambiar el tamaño desde la URL
    max_page_size = 100  # Tamaño máximo permitido

class CustomerViewSet(viewsets.ModelViewSet):

    queryset = Customer.objects.all().order_by('-id')
    serializer_class = CustomerSerializer
    pagination_class = CustomPagination
    filter_backends = [DjangoFilterBackend,filters.SearchFilter]
    search_fields = ['codigo', 'full_name', 'number']

    # filtros exactos
    filterset_fields = ['codigo','zona']  

    def create(self, request, *args, **kwargs):
        data = request.data
        has_meter = data.get('has_meter', True)
        meter_data = data.get('meter', None)

        try:
            # Validar duplicado de número si no tiene medidor
            if not has_meter and data.get('number'):
                if Customer.objects.filter(number=data['number']).exists():
                    return Response(
                        {'error': 'Ya existe un cliente con este número.'},
                        status=status.HTTP_400_BAD_REQUEST
                    )

            # Validar medidor antes de guardar el Customer
            if has_meter:
                if not meter_data:
                    return Response(
                        {'error': 'Este campo es obligatorio cuando el cliente tiene medidor.'},
                        status=status.HTTP_400_BAD_REQUEST
                    )
                if WaterMeter.objects.filter(code=meter_data.get('code')).exists():
                    return Response(
                        {'error': 'Este código de medidor ya existe.'},
                        status=status.HTTP_400_BAD_REQUEST
                    )

            with transaction.atomic():
                # Obtener último código y sumar 1
                last_code = Customer.objects.aggregate(max_code=Max('codigo'))['max_code']
                if last_code:
                    next_code = str(int(last_code) + 1).zfill(5)
                else:
                    next_code = "00001"

                # Asignar el nuevo código al cliente
                data['codigo'] = next_code

                customer_serializer = CustomerSerializer(data=data)
                customer_serializer.is_valid(raise_exception=True)
                customer = customer_serializer.save()

                if has_meter:
                    WaterMeter.objects.create(
                        customer=customer,
                        code=meter_data['code'],
                        installation_date=meter_data['installation_date']
                    )

                return Response(CustomerSerializer(customer).data, status=status.HTTP_201_CREATED)

        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    @action(detail=False, methods=["get"], url_path="by-code")
    def by_code_and_dni(self, request):
        codigo = request.query_params.get("codigo")
        dni = request.query_params.get("dni")

        if not codigo or not dni:
            return Response(
                {"error": "Debe proporcionar código y dni/ruc"},
                status=status.HTTP_400_BAD_REQUEST
            )

        try:
            customer = Customer.objects.get(codigo=codigo, number=dni)
        except Customer.DoesNotExist:
            return Response(
                {"error": "Cliente no encontrado"},
                status=status.HTTP_404_NOT_FOUND
            )

        serializer = CustomerWithDebtsSerializer(customer)
        return Response(serializer.data)
    
    @action(detail=False, methods=['post'])
    def import_excel(self, request):

        file = request.FILES.get('file')

        if not file:
            return Response({'error': 'No se proporcionó un archivo.'}, status=status.HTTP_400_BAD_REQUEST)

        try:
            df = pd.read_excel(
                file,
                engine='openpyxl',
                header=2,
                dtype={'Código': str}
            )
        except Exception as e:
            return Response({'error': f'Error al leer el archivo: {str(e)}'}, status=status.HTTP_400_BAD_REQUEST)

        # Obtenemos la zona por defecto (sin zona)
        default_zona = Zona.objects.filter(name__iexact="sin zona").first()

        for index, row in df.iterrows():

            codigo = str(row.get('Código'))

            # DNI/RUC
            number = to_none_if_empty(row.get('DNI/RUC.'))

            identity_document_type = 0

            if number and number.isdigit():
                if len(number) == 8:
                    identity_document_type = 1  # DNI
                elif len(number) == 11:
                    identity_document_type = 6  # RUC
            else:
                number = "00000000"  # Valor por defecto si está vacío o no es válido

            full_name = to_none_if_empty(row.get('Usuario/Cliente'))
            address = to_none_if_empty(row.get('Dirección'))
            calle_dir = row.get('cod_direc')
            zona_name = to_none_if_empty(row.get('Barrio'))
            
            if zona_name:

                zona_name = zona_name.strip().lower()
                zona = Zona.objects.filter(name__iexact=zona_name).first()
                if not zona:
                    zona = default_zona
            else:

                zona = default_zona

            # Normalizar valor
            if not calle_dir or str(calle_dir).strip() == '' or pd.isna(calle_dir):
                calle_dir = 1
            else:
                calle_dir = int(str(calle_dir).strip())

            calle = Calle.objects.get(pk = calle_dir)

            # Medidor
            code = to_none_if_empty(row.get('Cód.Medidor'))
            tiene_medidor_excel = to_none_if_empty(row.get('T.Med.'))

            if tiene_medidor_excel == "si":
                has_meter = True
            elif tiene_medidor_excel == "no":
                has_meter = False
            else:
                has_meter = True if code else False

            # Categoría
            category_id = to_none_if_empty(row.get('cod_categ')) or 6

     
            #Crear cliente
            customer = Customer.objects.create(
                codigo=codigo,
                identity_document_type=identity_document_type,
                full_name=full_name,
                number=number,
                address=address,
                has_meter=has_meter,
                category_id=category_id,
                calle = calle,
                zona = zona
            )

            # Crear medidor solo si aplica y no existe
            if has_meter and code:
                if not WaterMeter.objects.filter(code=code).exists():
                    WaterMeter.objects.create(
                        customer=customer,
                        code=code,
                        installation_date=now()
                    )

        return Response({"message": "Clientes importados correctamente"}, status=status.HTTP_200_OK)

class CashBoxViewSet(viewsets.ModelViewSet):
    
    queryset = CashBox.objects.all()
    serializer_class = CashBoxSerializer

    @action(detail=True, methods=["get"])
    def daily_report(self, request, pk=None):
        cashbox = self.get_object()

        movimientos = cashbox.movements.select_related(
            "concept", "invoice_payment__invoice__customer"
        )

        # Agrupamos movimientos por concepto
        conceptos_dict = defaultdict(list)
        for mov in movimientos:
            conceptos_dict[mov.concept].append(mov)

        # Construimos estructura para el template
        conceptos_data = []
        for concept, movs in conceptos_dict.items():
            total_concepto = sum([m.total for m in movs])
            conceptos_data.append({
                "concept": concept,
                "total": total_concepto,
                "movimientos": movs
            })

        total_general = sum([c["total"] for c in conceptos_data])

        html_string = render_to_string("reports/caja/daily.html", {
            "cashbox": cashbox,
            "conceptos": conceptos_data,
            "total_general": total_general,
        })

        pdf = HTML(string=html_string).write_pdf()
        response = HttpResponse(pdf, content_type="application/pdf")
        response["Content-Disposition"] = f'filename="reporte_caja_{cashbox.id}.pdf"'
        return response
    

    # @action(detail=True, methods=['get'], url_path="report_pdf")
    # def report_pdf(self, request, pk=None):

    #     cashbox = self.get_object()
    #     start_date = request.query_params.get("start")
    #     end_date = request.query_params.get("end")

    #     if not start_date or not end_date:
         
    #        return Response({"error":"Debes enviar start y end"}, status=status.HTTP_400_BAD_REQUEST)
        
    #     start_date = datetime.fromisoformat(start_date).date()
    #     end_date = datetime.fromisoformat(end_date).date()

    #     payments = cashbox.payments.filter(created_at__date__range=(start_date, end_date))

    #     total = sum(p.total for p in payments)

    #     by_method = {}
    #     for p in payments:

    #         by_method.setdefault(p.method, 0)
    #         by_method[p.method] += float(p.total)

    #     invoices = set(p.invoice for p in payments)

    #     html_string = render_to_string("reports/caja/cashbox_report_range.html", {

    #         "cashbox": cashbox,
    #         "payments": payments,
    #         "start_date": start_date,
    #         "end_date": end_date,
    #         "total": total,
    #         "by_method": by_method,
    #         "invoices": invoices,

    #     }) 

    #      # Generar PDF
    #     html = HTML(string=html_string)
    #     pdf = html.write_pdf()

    #     response = HttpResponse(pdf, content_type="application/pdf")
    #     response["Content-Disposition"] = f'inline; filename="reporte_caja_{cashbox.id}.pdf"'
    #     return response

    @action(detail=True, methods=["get"])
    def daily_report_pdf(self, request, pk=None):
        """
        Reporte diario en PDF: ingresos por método + detalle de facturas
        """
        cashbox = self.get_object()
        date = request.query_params.get("date", now().date())

        # Resumen por método
        payments_summary = (
            InvoicePayment.objects
            .filter(
                cashbox=cashbox,
                created_at__date=date,
                invoice__status="active"
            )
            .values("method")
            .annotate(total=Sum("total"))
            .order_by("method")
        )

        # Total general
        total = (
            InvoicePayment.objects
            .filter(
                cashbox=cashbox,
                created_at__date=date,
                invoice__status="active"
            )
            .aggregate(total=Sum("total"))["total"] or 0
        )

        # Detalle de facturas (clientes que pagaron)
        invoices = (
            Invoice.objects
            .filter(
                invoice_payments__cashbox=cashbox,
                invoice_payments__created_at__date=date,
                status="active"
            )
            .distinct()
        )

        html_string = render_to_string("reports/caja/daily.html", {
            "date": date,
            "cashbox": cashbox,
            "payments_summary": payments_summary,
            "total": total,
            "invoices": invoices,
        })

        # Generar PDF
        html = HTML(string=html_string)
        pdf = html.write_pdf()

        response = HttpResponse(pdf, content_type="application/pdf")
        response["Content-Disposition"] = f'inline; filename="reporte_caja_{cashbox.id}_{date}.pdf"'
        return response

class WaterMeterViewSet(viewsets.ModelViewSet):
    
    queryset = WaterMeter.objects.all()
    serializer_class = WaterMeterSerializer

class ReadingViewSet(viewsets.ModelViewSet):

    queryset = Reading.objects.all().order_by('period')
    serializer_class = ReadingSerializer
    filter_backends = [DjangoFilterBackend, filters.SearchFilter]
    filterset_class = ReadingFilter
    # Búsqueda parcial para Name
    # search_fields = ['full_name','number']

    @action(detail=False, methods=['post'])
    def import_excel(self, request):

        month_map = {
            "Lect.Ene": 1, "Lect.Feb": 2, "Lect.Mar": 3, "Lect.Abr": 4, "Lect.May": 5,
            "Lect.Jun": 6, "Lect.Jul": 7, "Lect.Ago": 8, "Lect.Sep": 9, "Lect.Oct": 10,
            "Lect.Nov": 11, "Lect.Dic": 12,
        }

        consumo_map = {
            "M3 Ene": 1, "M3 Feb": 2, "M3 Mar": 3, "M3 Abr": 4, "M3 May": 5,
            "M3 Jun": 6, "M3 Jul": 7, "M3 Ago": 8, "M3 Sep": 9, "M3 Oct": 10,
            "M3 Nov": 11, "M3 Dic": 12,
        }

        pago_map = {
            "Pag.Ene": 1, "Pag.Feb": 2, "Pag.Mar": 3, "Pag.Abr": 4, "Pag.May": 5,
            "Pag.Jun": 6, "Pag.Jul": 7, "Pag.Ago": 8, "Pag.Set": 9, "Pag.Oct": 10,
            "Pag.Nov": 11, "Pag.Dic": 12,
        }

        deuda_map = {
            "Enero": 1, "Febrero": 2, "Marzo": 3, "Abril": 4,
            "Mayo": 5, "Junio": 6, "Julio": 7, "Agosto": 8,
            "Setiembre": 9, "Octubre": 10, "Noviembre": 11, "Diciembre": 12,
        }

        file = request.FILES.get('file')

        if not file:
            return Response({'error': 'No se proporcionó un archivo.'}, status=status.HTTP_400_BAD_REQUEST)

        try:
            df = pd.read_excel(
                file,
                engine='openpyxl',
                header=2,
                dtype={'Código': str}
            )
        except Exception as e:
            return Response({'error': f'Error al leer el archivo: {str(e)}'}, status=status.HTTP_400_BAD_REQUEST)

        registros_creados = 0
        
        registros = []
        debts = []
        for index, row in df.iterrows():
        
            codigo = str(row.get('Código')).strip()
            customer = Customer.objects.get(codigo=codigo)

            for lect_col, month in month_map.items():

                consumo_col = [c for c, m in consumo_map.items() if m == month][0]
                deuda_col = [c for c, m in deuda_map.items() if m == month][0]
                pago_col = [c for c, m in pago_map.items() if m == month][0]

                current_reading = to_decimal_or_none(row.get(lect_col))
                consumption = to_decimal_or_none(row.get(consumo_col))
                deuda = to_decimal_or_none(row.get(deuda_col))
                pago = to_decimal_or_none(row.get(pago_col))

                # Si en este mes no hay lectura, consumo, deuda ni pago → cortamos
                if not any([current_reading, consumption, deuda, pago]):
                    break

                if consumption is not None:
                    previous_reading = current_reading - consumption
                else:
                    previous_reading = Decimal("0.00")

                if pago and pago > 0:
                    total_amount = pago
                    paid = True
                elif deuda and deuda > 0:
                    total_amount = deuda
                    paid = False
                else:
                    total_amount = Decimal("0.00")
                    paid = False

                period_date = date(2025, month, 1)
                # print(period_date, current_reading, previous_reading, consumption, total_amount, paid)

                registros.append(
                    Reading(
                        customer=customer,
                        period=date(2025, month, 1),
                        current_reading=current_reading or Decimal("0.00"),
                        previous_reading=previous_reading or Decimal("0.00"),
                        consumption=consumption or Decimal("0.00"),
                        total_amount=total_amount,
                        paid=paid
                    )
                )


            # print(codigo,"------")

        # Inserción masiva ignorando duplicados
        with transaction.atomic():
            
            # Guardar primero los readings
            Reading.objects.bulk_create(registros, ignore_conflicts=True)

            readings = Reading.objects.all()

            # Ahora crear los debts con referencia a los readings creados
            debts = []
            for reading in readings:
                debts.append(
                    Debt(
                        customer=reading.customer,
                        period=reading.period,
                        description="Excel",
                        amount=reading.total_amount,
                        paid=reading.paid,
                        reading=reading  # ✅ ya tiene ID
                    )
                )

            Debt.objects.bulk_create(debts, ignore_conflicts=True)

            # 🔎 Recuperar solo lecturas de este año (ejemplo 2025) que sean pagadas
            # readings = Reading.objects.filter(
            #     paid=True,
            #     period__year=2025  # <- o el año que corresponda al Excel
            # )

            # for r in readings:
            #     if r.total_amount > 0 and not InvoiceReading.objects.filter(reading=r).exists():
            #         invoice = Invoice.objects.create(
            #             customer=r.customer,
            #             total=r.total_amount,
            #             method="cash",
            #             reference=f"Factura generada por importación de Excel ({r.period.strftime('%B %Y')})"
            #         )
            #         InvoiceReading.objects.create(invoice=invoice, reading=r)

        return Response({"message": "Lecturas importadas correctamente"}, status=status.HTTP_200_OK)

    @action(detail=True, methods=['get'])
    def receipt(self, request, pk=None):
        """
        Generar PDF de un solo recibo (para pruebas o impresión individual)
        """
        reading = self.get_object()
        company = Company.objects.first()

        # obtener deudas anteriores no pagadas
        previous_debts = Debt.objects.filter(
            customer=reading.customer,
            paid=False,
            period__lt=reading.period
        ).order_by("period")

        # Agrupar por año
        yearly_data = defaultdict(lambda: {"total": 0, "months": []})
        for d in previous_debts:
            year = d.period.year
            month = d.period.month
            yearly_data[year]["total"] += float(d.amount)
            yearly_data[year]["months"].append(month)

        grouped_debts = []
        for year, data in yearly_data.items():
            min_month = min(data["months"])
            max_month = max(data["months"])
            grouped_debts.append({
                "year": year,
                "total": f"{data['total']:.2f}",
                "from_month": format_date(date(year, min_month, 1), "MMMM", locale="es").capitalize(),
                "to_month": format_date(date(year, max_month, 1), "MMMM", locale="es").capitalize(),
            })

        grouped_debts.sort(key=lambda x: x["year"], reverse=True)

        total_previous_debt = previous_debts.aggregate(total=Sum("amount"))["total"] or 0
        total_general = reading.total_amount + total_previous_debt

        # 🚀 armamos la misma estructura que en el masivo
        readings_context = [{
            "reading": reading,
            "grouped_debts": grouped_debts,
            "total_previous_debt": total_previous_debt,
            "total_general": total_general,
        }]

        html = render_to_string("agua/invoice_template.html", {
            "readings_context": readings_context,
            "company": company,
        })

        pdf_bytes = HTML(string=html, base_url=request.build_absolute_uri('/')).write_pdf()

        response = HttpResponse(pdf_bytes, content_type="application/pdf")
        response["Content-Disposition"] = f'inline; filename=recibo_{reading.customer.codigo}_{reading.period.strftime("%Y-%m")}.pdf"'
        return response
    
class ReadingGenerationViewSet(viewsets.ModelViewSet):

    queryset = ReadingGeneration.objects.all()
    serializer_class = ReadingGenerationSerializer

    def create(self, request, *args, **kwargs):

        """
        Sobrescribe el create para generar automáticamente
        las lecturas de clientes sin medidor para el periodo enviado.
        """
        period_str = request.data.get("period")

        if not period_str:

            return Response({"error": "Falta el periodo (YYYY-MM)"}, status=400)

        try:

            period_date = datetime.strptime(period_str + "-01", "%Y-%m-%d").date()

        except ValueError:

            return Response({"error": "Formato inválido de periodo"}, status=400)

        # validar si ya existe
        if ReadingGeneration.objects.filter(period=period_date).exists():
            return Response({"message": f"Ya se generaron lecturas para {period_str}"}, status=200)

        customers = Customer.objects.filter(has_meter=False)
        created = 0

        with transaction.atomic():

            for customer in customers:

                tariff = customer.category

                Reading.objects.create(
                    customer=customer,
                    period=period_date,
                    previous_reading=0,
                    current_reading=0,
                    consumption=0,
                    total_water=tariff.price_water,
                    total_sewer=tariff.price_sewer,
                    total_amount=tariff.price_water + tariff.price_sewer,
                    paid=False,
                    date_of_issue = request.data.get("date_of_issue"),
                    date_of_due = request.data.get("date_of_due"),
                    date_of_cute = request.data.get("date_of_cute")
                )
                created += 1

            # Crear la generación
            generation = ReadingGeneration.objects.create(
                period=period_date,
                created_by=request.user if request.user.is_authenticated else None,
                total_generated=created,
                notes="Generación automática para clientes sin medidor",
                date_of_issue = request.data.get("date_of_issue"),
                date_of_due = request.data.get("date_of_due"),
                date_of_cute = request.data.get("date_of_cute")
            )

        return Response({ "message": f"Se generaron {created} lecturas para el periodo {period_str}" }, status=status.HTTP_201_CREATED)

    @action(detail=True, methods=['get'])
    def download_receipts(self, request, pk=None):
        """
        Descargar ZIP de recibos agrupados por zona para este periodo
        """
        generation = self.get_object()
        readings = (
            Reading.objects.filter(
                period=generation.period,
                customer__zona__isnull=False
            )
            .select_related("customer", "customer__zona")
            .order_by("customer__zona__name", "customer__codigo")
        )

        if not readings.exists():
            return Response(
                {"error": "No hay lecturas con zona asignada para este periodo"},
                status=400
            )

        buffer = io.BytesIO()
        with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as zip_file:
            # Agrupar lecturas por zona
            zonas = {}
            for reading in readings:
                zona_name = reading.customer.zona.name
                zonas.setdefault(zona_name, []).append(reading)

            # Generar 1 PDF por zona
            for zona, zona_readings in zonas.items():
                html_content = render_to_string(
                    "agua/invoice_template.html",
                    {"readings": zona_readings, "zona": zona}
                )
                pdf_bytes = HTML(string=html_content).write_pdf()
                zip_file.writestr(f"{zona}.pdf", pdf_bytes)

        buffer.seek(0)
        response = HttpResponse(buffer, content_type="application/zip")
        response["Content-Disposition"] = (
            f'attachment; filename="recibos_{generation.period.strftime("%Y-%m")}.zip"'
        )
        return response

    @action(detail=True, methods=['get'])
    def download_all_receipts(self, request, pk=None):
        """
        Descargar un único PDF con todos los recibos de este periodo
        dentro de un ZIP
        """
        company = Company.objects.first()
        generation = self.get_object()
        readings = Reading.objects.filter(period=generation.period)
        
        zona_id = request.query_params.get("zona")

        if zona_id:
            
            readings = readings.filter(customer__zona_id=zona_id)

        if not readings.exists():
            return Response(
                {"error": "No hay lecturas con zona asignada para este periodo"},
                status=400
            )

        all_readings_context = []
        for reading in readings:

            # obtener deudas anteriores no pagadas
            previous_debts = Debt.objects.filter(
                customer=reading.customer,
                paid=False,
                period__lt=reading.period
            ).order_by("period")

            # Agrupar por año
            yearly_data = defaultdict(lambda: {"total": 0, "months": []})
            for d in previous_debts:
                year = d.period.year
                month = d.period.month
                yearly_data[year]["total"] += float(d.amount)
                yearly_data[year]["months"].append(month)

            grouped_debts = []
            for year, data in yearly_data.items():
                min_month = min(data["months"])
                max_month = max(data["months"])
                grouped_debts.append({
                    "year": year,
                    "total": f"{data['total']:.2f}",
                    "from_month": format_date(date(year, min_month, 1), "MMMM", locale="es").capitalize(),
                    "to_month": format_date(date(year, max_month, 1), "MMMM", locale="es").capitalize(),
                })

            grouped_debts.sort(key=lambda x: x["year"], reverse=True)

            total_previous_debt = previous_debts.aggregate(total=Sum("amount"))["total"] or 0
            total_general = reading.total_amount + total_previous_debt

            all_readings_context.append({
                "reading": reading,
                "grouped_debts": grouped_debts,
                "total_previous_debt": total_previous_debt,
                "total_general": total_general,
            })

        # Renderizamos todos los recibos (un reading por página)
        html_content = render_to_string("agua/invoice_template.html", {
            "readings_context": all_readings_context,
            "company": company,
        })

        pdf_bytes = HTML(string=html_content, base_url=request.build_absolute_uri('/')).write_pdf()

        # Devolvemos directamente el PDF
        response = HttpResponse(pdf_bytes, content_type="application/pdf")
        response["Content-Disposition"] = (
            f'attachment; filename="recibos_{generation.period.strftime("%Y-%m")}.pdf"'
        )

        return response
    
class DebtViewSet(viewsets.ModelViewSet):

    queryset = Debt.objects.all().order_by('period')
    serializer_class = DebtSerializer
    filter_backends = [DjangoFilterBackend, filters.SearchFilter]
    filterset_class = DebtFilter

    @action(detail=False, methods=['post'])
    def import_excel(self, request):

        file = request.FILES.get('file')

        if not file:

            return Response({'error': 'No se proporcionó un archivo.'}, status=status.HTTP_400_BAD_REQUEST)

        try:

            df = pd.read_excel(
                file,
                engine='openpyxl',
                header=2,
                dtype={'Código': str}
            )

        except Exception as e:

            return Response({'error': f'Error al leer el archivo: {str(e)}'}, status=status.HTTP_400_BAD_REQUEST)

        
        errores = []
        procesados = 0

        for index, row in df.iterrows():

            codigo = str(row.get('Código'))
            year = row.get('Año')
            meses_texto  = to_none_if_empty(row.get('Meses'))
            total = to_decimal_or_none(row.get('Agua'))

            if year != 2025:

                if not meses_texto:

                    errores.append({
                        "codigo": codigo,
                        "anio": year,
                        "total": total,
                        "error": "Campo 'Meses' vacío"
                    })

                    continue

                try:

                    customer = Customer.objects.get(codigo=codigo)

                except Customer.DoesNotExist:

                    errores.append({
                        "codigo": codigo,
                        "anio": year,
                        "meses": meses_texto,
                        "total": total,
                        "error": "Cliente no encontrado"
                    })

                    continue

                try:

                    periodos = generar_periodos(int(year), meses_texto)

                except Exception as e:

                    errores.append({
                        "codigo": codigo,
                        "anio": year,
                        "meses": meses_texto,
                        "total": total,
                        "error": f"Error al generar periodos: {str(e)}"
                    })

                    continue


                # Calcular monto por mes
                monto_por_mes = float(total) / len(periodos) if len(periodos) > 0 else 0

                # Crear deudas
                debts = [
                    Debt(
                        customer=customer,
                        period=periodo,
                        description="Excel",
                        amount=monto_por_mes,
                        paid=False
                    )
                    for periodo in periodos
                ]
                Debt.objects.bulk_create(debts, ignore_conflicts=True)
                procesados += len(debts)

        return Response({
            "procesados": procesados,
            "errores": errores
        }, status=status.HTTP_200_OK)

            # codigo = str(row.get('Código')).strip()
            # customer = Customer.objects.get(codigo=codigo)

            # for lect_col, month in month_map.items():

            #     consumo_col = [c for c, m in consumo_map.items() if m == month][0]
            #     deuda_col = [c for c, m in deuda_map.items() if m == month][0]
            #     pago_col = [c for c, m in pago_map.items() if m == month][0]

            #     current_reading = to_decimal_or_none(row.get(lect_col))

class InvoiceViewSet(viewsets.ModelViewSet):

    queryset = Invoice.objects.all().order_by('-id')
    serializer_class = InvoiceSerializer
    pagination_class = CustomPagination

    @action(detail=True, methods=['get'], url_path='ticket')
    def ticket_pdf(self, request, pk=None):

        invoice = get_object_or_404(Invoice, id=pk)

        # Usamos la relación inversa para evitar consultas innecesarias
        payments = invoice.invoice_debts.select_related('debt').order_by('debt__period')

        context = {
            "invoice": invoice,
            "customer": invoice.customer,
            "payments": payments,
            "total_paid": sum((p.debt.amount for p in payments), 0),
            "company_name":  "Empresa",
            "company_ruc": "99999999999",
            "company_logo": None
        }

        template = get_template('agua/invoice.html')
        html_string = template.render(context)

        pdf_buffer = io.BytesIO()
        css_path = os.path.join(settings.BASE_DIR, "static/css/ticket.css")

        HTML(string=html_string, base_url=request.build_absolute_uri()).write_pdf(
            pdf_buffer,
            stylesheets=[CSS(css_path)]
        )

        file_name = f"ticket_{invoice.id}.pdf"
        pdf_buffer.seek(0)
        response = HttpResponse(pdf_buffer.read(), content_type="application/pdf")
        response["Content-Disposition"] = f'inline; filename="{file_name}"'
        return response

    @action(detail=True, methods=['post'])
    def cancel(self, request, pk=None):
        invoice = self.get_object()
        invoice.cancel()
        return Response({"message": "Factura anulada"}, status=status.HTTP_200_OK)

    @action(detail=False, methods=['get'], url_path='daily-report')
    def daily_report(self, request, pk=None):

        report_date_str = request.query_params.get('date')

        if report_date_str:

           report_date = date.fromisoformat(report_date_str)
        
        else:

           report_date = date.today()
        
        invoices = Invoice.objects.filter(date=report_date, status='active')
        total_cash = invoices.filter(method="cash").aggregate(total=Sum("total"))["total"] or 0
        total_yape = invoices.filter(method="yape").aggregate(total=Sum("total"))["total"] or 0
        total = total_cash + total_yape

   
        html_string = render_to_string("reports/invoices/daily .html", {
            "report_date": report_date,
            "invoices": invoices,
            "total_cash": total_cash,
            "total_yape": total_yape,
            "grand_total": total,
        })

        pdf = HTML(string=html_string).write_pdf()

        response = HttpResponse(pdf, content_type="application/pdf")
        response["Content-Disposition"] = f'inline; filename="cobranzas_{report_date}.pdf"'
        return response

# class CompanyViewSet(ModelViewSet):

#     queryset = Company.objects.all()
#     serializer_class = CompanySerializer


class CategoryViewSet(viewsets.ModelViewSet):
    
    permission_classes = [IsAuthenticated]
    serializer_class = CategorySerializer
    queryset = Category.objects.all() 

    def get_queryset(self):

        return Category.objects.filter(state=True).order_by('id')

    @action(detail=False, methods=['post'])
    def import_excel(self, request):

        file = request.FILES.get('file')

        if not file:

            return Response({'error': 'No se proporcionó un archivo.'}, status=status.HTTP_400_BAD_REQUEST)

        try:

            extension = os.path.splitext(file.name)[1].lower()

            if extension == ".xls":

                df = pd.read_excel(file, engine="xlrd", dtype={'codigo': str})

            elif extension == ".xlsx":

                df = pd.read_excel(file, engine="openpyxl", dtype={'codigo': str})

            else:

                return Response({'error': 'Formato no soportado. Solo .xls o .xlsx'}, status=status.HTTP_400_BAD_REQUEST)

        except Exception as e:

            return Response({'error': f'Error al leer el archivo: {str(e)}'}, status=status.HTTP_400_BAD_REQUEST)

        for index, row in df.sort_values(by='codigo').iterrows():

            codigo = str(row.get('codigo')).zfill(2)  # Siempre 2 dígitos
            descrip = row.get('descrip')
            agua = row.get('agua')

            # Crear o actualizar registro
            Category.objects.update_or_create(
                codigo=codigo,
                defaults={
                    'name': descrip,
                    'price_water': agua,
                    'price_sewer': 0,  # Si tu Excel no trae alcantarillado
                    'has_meter': False  # Si quieres poner un valor por defecto
                }
            )

            print(f"Importado: {codigo} - {descrip} - {agua}")


        return Response({"message":"ubicacion cargada"}, status=status.HTTP_200_OK)

class ViaViewSet(viewsets.ModelViewSet):

    queryset = Via.objects.all().order_by('id')
    serializer_class = ViaSerializer
    filter_backends = [filters.SearchFilter, filters.OrderingFilter]
    search_fields = ['name']
    ordering_fields = ['name']

    @action(detail=False, methods=['post'])
    def import_excel(self, request):

        file = request.FILES.get('file')

        if not file:

            return Response({'error': 'No se proporcionó un archivo.'}, status=status.HTTP_400_BAD_REQUEST)

        try:
        
            df = pd.read_excel(
                    file,
                    engine='openpyxl',
                    dtype={
                        'tipo_dir': str,
                        'codigo': str
                    })

        except Exception as e:

            return Response({'error': f'Error al leer el archivo: {str(e)}'}, status=status.HTTP_400_BAD_REQUEST)

        for index, row in df.sort_values(by='tipo_dir').iterrows():
            name = row.get('abrv')
            codigo = str(row.get('tipo_dir')).zfill(2)  # Siempre 2 dígitos

            if Via.objects.filter(codigo=codigo).exists():
                continue

            via = Via(name=name, codigo=codigo)
            via.save()

        df = df.sort_values(by=['codigo'], ascending=True)
        for index, row in df.iterrows():

            codigo = str(row.get('codigo') or '').strip()
            name = str(row.get('nombre') or '').strip()
            codigo_via = str(row.get('tipo_dir') or '').strip()
            # print(codigo_via)

            if not name or not codigo_via:
                
               print(f'Fila {index + 2}: calle inválida (nombre o id_via vacío)')
               continue

            try:

                via = Via.objects.get(codigo=codigo_via)

            except Via.DoesNotExist:

                print(f'Fila {index + 2}: vía con código {codigo_via} no existe (para la calle "{name}")')

                continue

            if Calle.objects.filter(name=name, via=via).exists():

                print(f'Fila {index + 2}: ya existe la calle "{name}" en la vía {via.name}')
                continue

            calle = Calle(name=name, via=via, codigo=codigo)
            calle.save()
    

        return Response({"message":"ubicacion cargada"}, status=status.HTTP_200_OK)

class CalleViewSet(viewsets.ModelViewSet):

    queryset = Calle.objects.select_related('via').all().order_by('id')
    serializer_class = CalleSerializer
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = ['via']  # permite filtrar por tipo_via id
    search_fields = ['codigo','name']
    # ordering_fields = ['name']

class ZonaViewSet(viewsets.ModelViewSet):

    queryset = Zona.objects.all().order_by('id')
    serializer_class = ZonaSerializer
    filter_backends = [filters.SearchFilter]
    search_fields = ['codigo','name']


# class CashViewSet(ModelViewSet):
    
#     # permission_classes = [IsAuthenticated]

#     queryset = Cash.objects.all().order_by('id')
#     serializer_class = CashSerializer
#     pagination_class = CustomPagination

#     def destroy(self, request, *args, **kwargs):

#         cash = self.get_object()

#         if InvoicePayment.objects.filter(cash=cash).exists():

#            raise ValidationError({'error':'No se puede eliminar la caja porque tiene pagos asociados'})
        
#         return super().destroy(request, *args, **kwargs)

#     @action(detail=True, methods=['get'])
#     def close(self, request, pk=None):

#         cash = self.get_object()

#         if cash.date_closed:
           
#            return Respones({'error':'La caja ya esta cerrada'}, status=status.HTTP_400_BAD_REQUEST)
        
#         total = InvoicePayment.objects.filter(cash=cash).aggregate(total=Sum('total'))['total'] or 0

#         cash.income = total
#         cash.final_balance = cash.beginning_balance + total
#         cash.date_closed = now()
#         cash.state = False
#         cash.save()

#         return Response({'message':'Caja cerrada'})

#     @action(detail=True, methods=['get'])
#     def report(self, request, *args, **kwargs):
        
#         cash = self.get_object()

#         report_type = request.GET.get('type', 'daily')  # daily, monthly, custom

#         if report_type == 'daily':

#             report_date = request.GET.get('date')

#             date_obj = datetime.strptime(report_date, '%Y-%m-%d').date()
#             payments = InvoicePayment.objects.filter(
#                 cash=cash,
#                 invoice__date_of_issue = report_date

#             ).select_related('invoice', 'payment_method')

#             # Agrupar ingresos por concepto (tipo de pago)
#             income_by_concept = payments.values(
#                 'payment_method__description'
#             ).annotate(
#                 total=Sum('total')
#             ).order_by('payment_method__description')

#             # Calcular totales
#             total_income = payments.aggregate(total=Sum('total'))['total'] or 0
#             calculated_balance = cash.beginning_balance + total_income
            
#             context = {
#                 'payments' : payments,
#                 'date': date_obj,
#                 'opening_balance': float(cash.beginning_balance),
#                 'income_by_concept': list(income_by_concept),
#                 'total_income': float(total_income),
#                 'calculated_balance': float(calculated_balance),
#                 'final_balance': float(cash.final_balance) if cash.final_balance else None,
#                 # 'is_closed': cash.state,
#                 'reference_number': cash.reference_number,
#             }
    
            
#             html_string = render_to_string('reports/daily_balance.html', context)
#             pdf = HTML(string=html_string).write_pdf()
            
#             response = HttpResponse(pdf, content_type='application/pdf')
#             filename = f"deudas_clientes_{datetime.now().strftime('%Y%m%d')}.pdf"
#             response['Content-Disposition'] = f'inline; filename="{filename}"'
#             return response

#         elif report_type == 'range':
#             start_date = request.GET.get('start_date')
#             end_date = request.GET.get('end_date')

         
#             # Validar que ambas fechas existan
#             if not start_date or not end_date:
#                 return Response({'error': 'Debe proporcionar start_date y end_date'}, status=400)

#             # Convertir a objetos fecha
#             start_obj = datetime.strptime(start_date, '%Y-%m-%d').date()
#             end_obj = datetime.strptime(end_date, '%Y-%m-%d').date()

#             # Filtrar los pagos dentro del rango
#             payments = InvoicePayment.objects.filter(
#                 cash=cash,
#                 invoice__date_of_issue__range=(start_obj, end_obj)
#             ).select_related('invoice', 'payment_method')

#             # Agrupar por método de pago
#             income_by_concept = payments.values(
#                 'payment_method__description'
#             ).annotate(
#                 total=Sum('total')
#             ).order_by('payment_method__description')

#             total_income = payments.aggregate(total=Sum('total'))['total'] or 0
#             calculated_balance = cash.beginning_balance + total_income

#             # Formateo bonito del rango

#             context = {
#                 'report_type' : report_type,
#                 'payments': payments,
#                 'date': start_obj,
#                 'end_date': end_obj,
#                 'opening_balance': float(cash.beginning_balance),
#                 'income_by_concept': list(income_by_concept),
#                 'total_income': float(total_income),
#                 'calculated_balance': float(calculated_balance),
#                 'final_balance': float(cash.final_balance) if cash.final_balance else None,
#                 'is_closed': cash.date_closed is not None,
#                 'reference_number': cash.reference_number,
#             }

#             html_string = render_to_string('reports/daily_balance.html', context)
#             pdf = HTML(string=html_string, base_url=request.build_absolute_uri('/')).write_pdf()

#             response = HttpResponse(pdf, content_type='application/pdf')
#             filename = f"reporte_caja_{datetime.now().strftime('%Y%m%d')}.pdf"
#             response['Content-Disposition'] = f'inline; filename="{filename}"'
#             return response

# class ZonaViewSet(ModelViewSet):
    
#     permission_classes = [IsAuthenticated]
#     queryset = Zona.objects.all().order_by('id')
#     serializer_class = ZonaSerializer

# class ServiceViewSet(ModelViewSet):
    
#     permission_classes = [IsAuthenticated]
#     queryset = Service.objects.all().order_by('id')
#     serializer_class = ServiceSerializer

# class CalleViewSet(ModelViewSet):
    
#     permission_classes = [IsAuthenticated]

#     queryset = Calle.objects.all().order_by('id')
#     serializer_class = CalleSerializer
#     filter_backends = [filters.SearchFilter]
#     search_fields = ["name"]

# class CustomerUnpaidInvoicesView(APIView):
    
#     def get(self, request, dni):
#         try:
#             # Buscar al cliente por DNI
#             customer = Customer.objects.get(dni=dni)

#             # Obtener facturas impagas
#             unpaid_invoices = Invoice.objects.filter(reading__customer=customer, is_paid=False)

#             # Obtener pagos realizados
#             # payments = Payment.objects.filter(invoice__reading__customer=customer)

#             # Serializar datos
#             customer_data = CustomerSerializer(customer).data
#             unpaid_invoices_data = InvoiceSerializer(unpaid_invoices, many=True).data
#             # payments_data = PaymentSerializer(payments, many=True).data

#             return Response({
#                 'customer': customer_data,
#                 'unpaid_invoices': unpaid_invoices_data,
#                 # 'payments': payments_data
#             }, status=status.HTTP_200_OK)
        
#         except Customer.DoesNotExist:
#             return Response({'error': 'Cliente no encontrado'}, status=status.HTTP_404_NOT_FOUND)

# class TariffViewSet(ModelViewSet):
    
#     queryset = Tariff.objects.all()
#     serializer_class = TariffSerializer

# # REPORTE

# class PDFRecibosPorCalleApiView(APIView):

#     def get(self, request, pk, periodo, *args, **kwargs):

#         company = Company.objects.first()
#         css_path = os.path.join(settings.BASE_DIR, "static/css/invoice_style.css")

#         calle = Calle.objects.get(pk = pk)
#         periodo_date = datetime.strptime(periodo, "%Y-%m")
#         mes = periodo_date.month
#         anio = periodo_date.year
#         readings = Reading.objects.filter(customer__calle=calle,issue_date__month=mes,issue_date__year=anio)
      
#         combined_html = ""
#         template = get_template("agua/invoice_template.html")

#         for reading in readings:
          
#             previous_reading = Reading.objects.filter(
#                 customer=reading.customer,
#                 reading_date__lt=reading.reading_date
#             ).order_by('-reading_date').first()

#             unpaid_readings = Reading.objects.filter(
#                 customer=reading.customer,
#                 is_paid=False,
#                 due_date__lt=reading.reading_date
#             ).exclude(id=reading.id)
            
#             consumption_excess = max(0, reading.consumption - reading.customer.tariff.max_consumption)
#             total_excess_charge = consumption_excess * reading.customer.tariff.extra_rate
#             total_due = sum(r.total_amount for r in unpaid_readings)
#             total = reading.total_amount + total_due

#             context = {
#                 "company": company,
#                 "customer": reading.customer,
#                 "reading": reading,
#                 "previous_reading": previous_reading,
#                 "consumption_excess": consumption_excess,
#                 "total_excess_charge": total_excess_charge,
#                 "unpaid_readings": unpaid_readings,
#                 "total_due": total_due,
#                 "total" : total,
#                 "company_logo": request.build_absolute_uri(company.logo.url) if company and company.logo else None
#             }

#             html_string = template.render(context)
#             combined_html += html_string + '<p style="page-break-after: always;"></p>'  # salto de página

#         # Generar PDF combinado
#         pdf_buffer = BytesIO()
#         HTML(string=combined_html, base_url=request.build_absolute_uri()).write_pdf(
#             pdf_buffer, stylesheets=[CSS(css_path)]
#         )
#         pdf_buffer.seek(0)

#         response = HttpResponse(pdf_buffer.read(), content_type="application/pdf")
#         response["Content-Disposition"] = f'inline; filename="recibos_{calle.name}.pdf"'
#         return response

# class PDFGeneratorAPIView(APIView):

#     def get(self, request, invoice_id, *args, **kwargs):
        
#         invoice = get_object_or_404(Invoice, id=invoice_id)
#         company = Company.objects.first()
#         customer = invoice.customer
#         payments = InvoiceReading.objects.filter(invoice=invoice).order_by('reading__reading_date')

#         context = {
#             "invoice": invoice,
#             "customer": customer,
#             "payments": payments,
#             "total_paid": sum((p.amount_paid for p in payments), 0),
#             "company_name": company.name if company else "Empresa",
#             "company_ruc": company.ruc if company else "99999999999",
#             "company_logo": request.build_absolute_uri(company.logo.url) if company and company.logo else None
#         }

#         template = get_template('agua/hola.html')
#         html_string = template.render(context)

#         pdf_buffer = BytesIO()
#         css_path = os.path.join(settings.BASE_DIR, "static/css/ticket.css")

#         HTML(string=html_string, base_url=request.build_absolute_uri()).write_pdf(pdf_buffer, stylesheets=[CSS(css_path)])

#         pdf_buffer.seek(0)
#         response = HttpResponse(pdf_buffer.read(), content_type="application/pdf")
#         response["Content-Disposition"] = 'inline; filename="invoice_ticket.pdf"'
#         return response

# class PDFReciboApiView(APIView):

#     def get(self, request, reading_id, *args, **kwargs):   

#         reading = Reading.objects.get(id=reading_id)
#         company = Company.objects.first()  # Suponiendo que hay una sola empresa

#         # Obtener la lectura anterior de este cliente
#         previous_reading = Reading.objects.filter(
#             customer=reading.customer,
#             reading_date__lt=reading.reading_date
#         ).order_by('-reading_date').first()

#         # Cálculo del consumo excedente
#         consumption_excess = max(0, reading.consumption - reading.customer.tariff.max_consumption)
#         total_excess_charge = consumption_excess * reading.customer.tariff.extra_rate

#         # Buscar lecturas impagas anteriores del cliente
#         unpaid_readings = Reading.objects.filter(
#             customer=reading.customer,
#             is_paid=False,
#             due_date__lt=reading.reading_date
#         ).exclude(id=reading.id)
        
#         total_due = sum(r.total_amount for r in unpaid_readings)

#         total =  reading.total_amount + total_due

#         context = {
#             "company": company,
#             "customer": reading.customer,
#             "reading": reading,
#             "previous_reading": previous_reading,
#             "consumption_excess": consumption_excess,
#             "total_excess_charge": total_excess_charge,
#             "unpaid_readings": unpaid_readings,
#             "total_due": total_due,
#             "total" : total,
#             "company_logo": request.build_absolute_uri(company.logo.url) if company and company.logo else None
#         }
#         template = get_template("agua/invoice_template.html")
#         html_string = template.render(context)

#         pdf_buffer = BytesIO()
#         css_path = os.path.join(settings.BASE_DIR, "static/css/invoice_style.css")

#         HTML(string=html_string, base_url=request.build_absolute_uri()).write_pdf(pdf_buffer, stylesheets=[CSS(css_path)])

#         pdf_buffer.seek(0)
#         response = HttpResponse(pdf_buffer.read(), content_type="application/pdf")
#         response["Content-Disposition"] = 'inline; filename="invoice.pdf"'
#         return response
    
# class DebtReportViewSet(APIView):

#     def get(self, request):
  
#         # Parámetros de filtrado
#         months = request.query_params.get('months', 6)  # Default: últimos 6 meses
#         zona = request.query_params.get('zona', None)
        
#         # Calculamos fecha de corte
#         from dateutil.relativedelta import relativedelta
#         cutoff_date = datetime.now() - relativedelta(months=int(months))
        
#         # Consulta optimizada
#         customers = Customer.objects.annotate(
#             total_debt=Sum('readings__total_amount',
#                           filter=Q(readings__is_paid=False) &
#                                  Q(readings__reading_date__gte=cutoff_date)),
#             debt_months=Count('readings__reading_date__month',
#                              distinct=True,
#                              filter=Q(readings__is_paid=False) &
#                                      Q(readings__reading_date__gte=cutoff_date))
#         ).filter(total_debt__gt=0).order_by('full_name')
        
#         if zona:
#             customers = customers.filter(calle__zona__id=zona)
        
#         # Preparar datos para el template
#         report_data = []
#         for customer in customers:
#             # Obtener meses adeudados
#             unpaid_months = Reading.objects.filter(
#                 customer=customer,
#                 is_paid=False,
#                 reading_date__gte=cutoff_date
#             ).dates('reading_date', 'month', order='ASC')
            
#             report_data.append({
#                 'id': customer.id,
#                 'name': customer.full_name,
#                 'address': customer.address,
#                 'zone': customer.calle.zona.name if customer.calle.zona else '',
#                 'total_debt': customer.total_debt,
#                 'debt_months': customer.debt_months,
#                 'months_list': [date.strftime("%b-%Y") for date in unpaid_months]
#             })
        
#         # Generar PDF
#         context = {
#             'customers': report_data,
#             'report_date': datetime.now().strftime("%d/%m/%Y"),
#             'cutoff_date': cutoff_date.strftime("%d/%m/%Y"),
#             'title': f"Reporte de Deudas (Últimos {months} meses)"
#         }
        
#         html_string = render_to_string('reports/debt_report.html', context)
#         pdf = HTML(string=html_string).write_pdf()
        
#         response = HttpResponse(pdf, content_type='application/pdf')
#         filename = f"deudas_clientes_{datetime.now().strftime('%Y%m%d')}.pdf"
#         response['Content-Disposition'] = f'inline; filename="{filename}"'
#         return response
    
# # GLOBAL API VIEW

# class TotalDashboard(APIView):

#     def get(self, request):

#         total_invoices = Invoice.objects.count()
#         total_sum = Invoice.objects.aggregate(total_sum=Sum('total_amount'))['total_sum'] or 0

#         total_customers = Customer.objects.count()
#         total_readings = Reading.objects.count()

#         return Response({
#             "total_invoices": total_invoices,
#             "total_sum": float(total_sum),
#             "total_customers": total_customers,
#             "total_readings": total_readings,
#         })

# class FinancialSummaryAPIView(APIView):

    # permission_classes = [IsAuthenticated]

    # def get(self, request):
        
    #     year = int(request.query_params.get('year', datetime.now().year))

    #     ingresos = InvoicePayment.objects.filter(invoice__date_of_issue__year=year).aggregate(total=Sum('total'))['total'] or 0
    #     egresos = Expense.objects.filter(date_of_issue__year=year).aggregate(total=Sum('total'))['total'] or 0
    #     utilidad = ingresos - egresos

    #     data = [

    #         {
    #             "name": "ingresos",
    #             "value": ingresos,
    #         },
    #         {
    #             "name": "egresos",
    #             "value": egresos,
    #         },
    #         {
    #             "name": "utilidad",
    #             "value": utilidad,
    #         }

    #     ]

    #     return Response(data)